﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;

namespace GraniteFortWorth_WebsiteApplication
{
    public partial class SiteClassic : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            bool showWeekendSpecials = true;
            string query = "Select ShowWeekendSpecials from tblSETTINGS where ID=1";
            string connect = SqlDataSourceTickerText.ConnectionString;
            OleDbConnection conn = new OleDbConnection(connect);
            OleDbCommand cmd = new OleDbCommand(query, conn);
            conn.Open();
            showWeekendSpecials = Convert.ToBoolean(cmd.ExecuteScalar());
            conn.Close();

            if (!showWeekendSpecials)
                divWeekendSpecials.Style.Add("visibility", "hidden");   
                //.Attributes.Add("style","visibility:hidden");
        }
    }
}