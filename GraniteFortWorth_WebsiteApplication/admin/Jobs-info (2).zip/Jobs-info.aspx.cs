﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;

using System.IO;
using System.Net;
using System.Net.Mail;
using System.Text;

using Google.GData;
using Google.GData.Calendar;
using Google.GData.Client;

namespace GraniteFortWorth_WebsiteApplication.admin
{
    public partial class Jobs_info : System.Web.UI.Page
    {
        private string strStatusID = String.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {

            if (FormView2.CurrentMode == FormViewMode.Edit)
            {
                TextBox txtUserJob = (TextBox)FormView2.FindControl("UserJobNoTextBox");
                if (String.IsNullOrEmpty(txtUserJob.Text))
                {
                    txtUserJob.Text = ((TextBox)(FormView2.FindControl("OnlineQuoteIDLabel1"))).Text;
                }
            }
            else
            {
                if (strStatusID == "8")
                {
                    string myScript = "\n<script type=\"text/javascript\" language=\"Javascript\" id=\"EventScriptBlock\">\n";
                    myScript += "alert('Job status is now Reference. It is highly recommended to ask this customer to write us a review in Angies List.'); ";
                    myScript += "\n\n </script>";
                    Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "myKey", myScript, false);
                }
            }

        }

        protected void EditButton_Click(object sender, EventArgs e)
        {
            /*
            Literal txtUserJob = (Literal)FormView2.FindControl("UserJobNoLabel");
                 if (String.IsNullOrEmpty(txtUserJob.Text))
                 {
                     string query = "UPDATE tblOnlineQuotes SET UserJobNo = " + (Convert.ToInt32(((Literal)FormView2.FindControl("OnlineQuoteIDLabel")).Text) + 331) + " WHERE OnlineQuoteID = " + Request.QueryString["OnlineQuoteID"];
                     string connect = SqlDataSource2.ConnectionString;
                     OleDbConnection conn = new OleDbConnection(connect);
                     OleDbCommand cmd = new OleDbCommand(query, conn);
                     conn.Open();
                     cmd.ExecuteNonQuery();
                     conn.Close();
                 }
             * */
        }

        protected void UpdateButton_Click(object sender, EventArgs e)
        {
            /*
            TextBox txtUserJob = (TextBox)FormView2.FindControl("UserJobNoTextBox");
            if (String.IsNullOrEmpty(txtUserJob.Text))
            {
                string query = "UPDATE tblOnlineQuotes SET UserJobNo = " + (Convert.ToInt32(((Literal)FormView2.FindControl("OnlineQuoteIDLabel1")).Text) + 331) + " WHERE OnlineQuoteID = " + Request.QueryString["OnlineQuoteID"];
                string connect = SqlDataSource2.ConnectionString;
                OleDbConnection conn = new OleDbConnection(connect);
                OleDbCommand cmd = new OleDbCommand(query, conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
             */
        }

        protected string FindEditControl(string ControlID)
        {
            string ControlName = string.Empty;
            if (FormView2.CurrentMode == FormViewMode.Edit)
                ControlName = FormView2.FindControl(ControlID).ClientID;
            else
                ControlName = FormView2.FindControl("TrushControlTextBox").ClientID; 

            return ControlName;
        }

        protected void FormView2_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
        {
            strStatusID = ((DropDownList)FormView2.FindControl("DropDownList5")).SelectedValue;
            string strOnlineQuoteID = Request.QueryString["OnlineQuoteID"];
            
            DateTime dateValue;
            
            if (strStatusID == "8")
            {
                if (Request.Form["confirm_value"] == "Yes")
                {
                    SendAngiesListReviewRequest();
                }
            }
            else if (strStatusID == "6" && DateTime.TryParse(((TextBox)FormView2.FindControl("InstallDateTextBox")).Text, out dateValue))
            {
                try
                {
                    CreateUpdateGoogleInstallCalendar(strOnlineQuoteID);                                                      
                }
                catch (Exception ex)
                {
                    string myScript = "\n<script type=\"text/javascript\" language=\"Javascript\" id=\"EventScriptBlock\">\n";
                    //myScript += "alert('Failed to create/update the Google Install Calendar. Please try again later.'); ";
                    myScript += "alert('Upgrading of Google Calendar API to v3 is at work. Please do a manual updating of the Install Calendar. '); ";
                    myScript += "window.open('https://www.google.com/calendar/render#g%7Cmonth-3+22874+22918+22898', '_blank', 'height=' + screen.height + ',width=' + screen.width + ',resizable=yes,scrollbars=yes'); ";
                    myScript += "\n\n </script>";
                    Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "myKey", myScript, false);
                }
            }
            else if (strStatusID == "9")
            {
                try
                {
                    DeleteGoogleInstallCalendar(strOnlineQuoteID);
                }
                catch (Exception ex)
                {
                    string myScript = "\n<script type=\"text/javascript\" language=\"Javascript\" id=\"EventScriptBlock\">\n";
                    myScript += "alert('Upgrading of Google Calendar API to v3 is at work. Please do a manual updating of the Install Calendar. '); ";
                    myScript += "window.open('https://www.google.com/calendar/render#g%7Cmonth-3+22874+22918+22898', '_blank', 'height=' + screen.height + ',width=' + screen.width + ',resizable=yes,scrollbars=yes'); ";
                    myScript += "\n\n </script>";
                    Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "myKey", myScript, false);
                }
            }
        }

        protected void CreateUpdateGoogleInstallCalendar(string strOnlineQuoteID)
        {          
            List<GoogleCalendarAppointmentModel> GoogleCalendarAppointmentModelList = new List<GoogleCalendarAppointmentModel>();
            GoogleCalendarAppointmentModel GoogleCalendarAppointmentModelObj = new GoogleCalendarAppointmentModel();

            //vars for Install email notification
            string var_ToEmail = String.Empty;
            string var_ToName = String.Empty;
            string var_InstallDate = String.Empty;
            string var_stone = String.Empty;
            string var_edge = String.Empty;
            string var_sink = String.Empty;

            #region populate GoogleAppointment values

            //Retrieve Granite/SF info
            string query2 = "SELECT SlabColorName AS SLABNAME, str(SF) + 'sf ) ' AS SFVAL FROM SummaryStoneQry WHERE OnlineQuoteID = " + strOnlineQuoteID;
            string connect2 = SqlDataSource2.ConnectionString;
            OleDbConnection conn2 = new OleDbConnection(connect2);
            OleDbCommand cmd2 = new OleDbCommand(query2, conn2);
            conn2.Open();
            OleDbDataReader JobInfoDataReader2 = cmd2.ExecuteReader();

            int c=1;
            while (JobInfoDataReader2.Read())
            {
                if (c < 2)
                {
                    if (!String.IsNullOrEmpty(JobInfoDataReader2.GetValue(1).ToString()))
                    {
                        GoogleCalendarAppointmentModelObj.EventDetails += "STONE: (" + JobInfoDataReader2.GetValue(1).ToString() + JobInfoDataReader2.GetValue(0).ToString();
                        var_stone += "(" + JobInfoDataReader2.GetValue(1).ToString() + JobInfoDataReader2.GetValue(0).ToString();
                    }
                }
                else
                {
                    GoogleCalendarAppointmentModelObj.EventDetails += "," + JobInfoDataReader2.GetValue(1).ToString() + JobInfoDataReader2.GetValue(0).ToString();
                    var_stone += "<br / >(" + JobInfoDataReader2.GetValue(1).ToString() + JobInfoDataReader2.GetValue(0).ToString();
                }
                c++;
            }
            JobInfoDataReader2.Close();
            conn2.Close();

            string strCurrentEdge = ((DropDownList)FormView2.FindControl("EdgeDropDownList1")).SelectedItem.Text;
            GoogleCalendarAppointmentModelObj.EventDetails += !String.IsNullOrEmpty(strCurrentEdge) ? " | EDGE: " + strCurrentEdge : String.Empty;
            var_edge = strCurrentEdge;
            //;

            //Retrieve Sink info
            string query5 = "SELECT SinkName, Quantity FROM SummarySinksQry WHERE OnlineQuoteID = " + strOnlineQuoteID;
            string connect5 = SqlDataSource2.ConnectionString;
            OleDbConnection conn5 = new OleDbConnection(connect5);
            OleDbCommand cmd5 = new OleDbCommand(query5, conn5);
            conn5.Open();
            OleDbDataReader JobInfoDataReader5 = cmd5.ExecuteReader();

            int c5 = 1;
            while (JobInfoDataReader5.Read())
            {
                if (c5 < 2)
                {
                    if (!String.IsNullOrEmpty(JobInfoDataReader5.GetValue(1).ToString()))
                    {
                        GoogleCalendarAppointmentModelObj.EventDetails += " | SINK: " + JobInfoDataReader5.GetValue(1).ToString() + " " + JobInfoDataReader5.GetValue(0).ToString();
                        var_sink += "( " + JobInfoDataReader5.GetValue(1).ToString() + " ) " + JobInfoDataReader5.GetValue(0).ToString();
                    }
                }
                else
                {
                    GoogleCalendarAppointmentModelObj.EventDetails += ", " + JobInfoDataReader5.GetValue(1).ToString() + " " + JobInfoDataReader5.GetValue(0).ToString();
                    var_sink += "<br />( " + JobInfoDataReader5.GetValue(1).ToString() + " ) " + JobInfoDataReader5.GetValue(0).ToString();
                }
                c5++;
            }
            JobInfoDataReader5.Close();
            conn5.Close();
           

            //Retrieve Customer Install Info
            string query1 = "SELECT CustomerFirstName + ' ' + CustomerLastName AS CustomerName, Address + ', ' + City + ', ' + State  AS InstallAddress, "
                + " InstallDate, InstallTime, Notes, ZipCode, Email  FROM tblOnlineQuotes WHERE OnlineQuoteID = " + strOnlineQuoteID;
            string connect1 = SqlDataSource2.ConnectionString;
            OleDbConnection conn1 = new OleDbConnection(connect1);
            OleDbCommand cmd1 = new OleDbCommand(query1, conn1);
            conn1.Open();
            OleDbDataReader JobInfoDataReader = cmd1.ExecuteReader();

            while (JobInfoDataReader.Read())
            {
                GoogleCalendarAppointmentModelObj.EventID = strOnlineQuoteID;
                GoogleCalendarAppointmentModelObj.EventTitle = JobInfoDataReader.GetString(0) + " Install";
                var_ToName = JobInfoDataReader.GetString(0);
                GoogleCalendarAppointmentModelObj.EventStartTime = DateTime.Parse(JobInfoDataReader.GetDateTime(2).ToShortDateString()).AddHours(-2);
                string strInstallTime = JobInfoDataReader.GetValue(3).ToString();
                var_InstallDate = (GoogleCalendarAppointmentModelObj.EventStartTime.AddDays(1)).ToLongDateString() + " " + strInstallTime;                
                GoogleCalendarAppointmentModelObj.EventEndTime = GoogleCalendarAppointmentModelObj.EventStartTime.AddHours(2);
                //Giving the proper location so you can view on the map in google calendar
                GoogleCalendarAppointmentModelObj.EventLocation = JobInfoDataReader.GetValue(1).ToString() + " " + JobInfoDataReader.GetValue(5).ToString();
                GoogleCalendarAppointmentModelObj.EventDetails += !String.IsNullOrEmpty(JobInfoDataReader.GetValue(3).ToString()) ? " | INSTALL TIME: " + strInstallTime : String.Empty;
                GoogleCalendarAppointmentModelObj.EventDetails += !String.IsNullOrEmpty(JobInfoDataReader.GetValue(4).ToString()) ? " | NOTES: " + JobInfoDataReader.GetValue(4).ToString() : String.Empty;
                var_ToEmail = JobInfoDataReader.GetString(6);
            }
            JobInfoDataReader.Close();
            conn1.Close();
            
            GoogleCalendarAppointmentModelList.Add(GoogleCalendarAppointmentModelObj);
            #endregion

            #region Add event to google calendar

            if (GoogleCalendarManager.AddUpdateDeleteEvent(GoogleCalendarAppointmentModelList, 0) == true)
            {
                if (Request.Form["confirm_value"] == "Yes")
                {
                    SendInstallEmail(var_ToEmail, var_ToName, var_InstallDate, var_stone, var_edge, var_sink);
                }
                //LblMessage.Text = "Event Created / updated successfully. Go to <a href='https://www.google.com/calendar/' target='blank'>Google Calendar</a> to view your event ";
                //BtnDeleteEvent.Enabled = true;
            }           

            #endregion
        }

        protected void DeleteGoogleInstallCalendar(string strOnlineQuoteID)
        {
            List<GoogleCalendarAppointmentModel> GoogleCalendarAppointmentModelList = new List<GoogleCalendarAppointmentModel>();
            GoogleCalendarAppointmentModel GoogleCalendarAppointmentModelObj = new GoogleCalendarAppointmentModel();

            #region populate GoogleAppointment values
            GoogleCalendarAppointmentModelObj.EventID = strOnlineQuoteID;
            GoogleCalendarAppointmentModelObj.DeleteAppointment = true;
            GoogleCalendarAppointmentModelList.Add(GoogleCalendarAppointmentModelObj);
            #endregion

                if (GoogleCalendarManager.AddUpdateDeleteEvent(GoogleCalendarAppointmentModelList, 0) == true)
                {
                    //LblMessage.Text = "Event deleted successfully. Go to <a href='https://www.google.com/calendar/' target='blank'>Google Calendar</a> to view your event ";
                    //BtnDeleteEvent.Enabled = false;
                }
        }

        private void SendInstallEmail(string var_ToEmail, string var_ToName, string var_InstallDate, string var_stone, string var_edge, string var_sink)
        {
            MailMessage message = new MailMessage();
            message.From = new MailAddress("webform@granitesouthlake.com");

            message.IsBodyHtml = true;

            // Proper Authentication Details need to be passed when sending email from gmail
            System.Net.NetworkCredential mailAuthentication = new
                System.Net.NetworkCredential("webform@granitesouthlake.com", "2much4me");

            // Smtp Mail server of Gmail is "smpt.gmail.com" and it uses port no. 587
            // For different server like yahoo this details changes and you can
            // Get it from respective server.
            System.Net.Mail.SmtpClient mailClient = new System.Net.Mail.SmtpClient("smtp.granitesouthlake.com", 587);

            // Enable SSL
            //mailClient.EnableSsl = true;
            mailClient.UseDefaultCredentials = false;
            mailClient.Credentials = mailAuthentication;

            //add accounts to notify
            message.To.Add(new MailAddress(var_ToEmail));
            message.To.Add(new MailAddress("info@granitesouthlake.com"));
            message.ReplyToList.Add(new MailAddress("dhitt0327@yahoo.com"));
            message.ReplyToList.Add(new MailAddress("rlowman64@gmail.com"));

            message.Subject = "[DFW Wholesale Granite] - Install Job Verification";
            System.Text.StringBuilder builder = new System.Text.StringBuilder();
            builder.AppendLine("<html><body><div style=\"padding:15px;background-color: #F8F8F8; font-family:Verdana, Geneva, Tahoma, sans-serif;font-size:small;\">");
            builder.AppendLine("<div style=\"border:2px solid #a1a1a1;padding:10px 40px; background:#dddddd;border-radius:25px; font-family:Georgia, 'Times New Roman', Times, serif; font-size:xx-large;text-align:center\">");
            builder.AppendLine("<a href=\"http://www.granitesouthlake.com\" style=\"color:black;text-decoration:none;\">DFW WHOLESALE GRANITE</a></div>");
            builder.AppendLine("<p>Dear <strong>" + var_ToName + "</strong>,</p>");
            builder.AppendLine("<p>Your Counter Tops are scheduled for install on " + var_InstallDate + ". ");
            builder.AppendLine("Please review the following items to confirm that we have the correct components for your job:</p>");
            builder.AppendLine("<table style=\"width: 80%;border-collapse:collapse;font-family:Verdana, Geneva, Tahoma, sans-serif;font-size:small;\">");
            builder.AppendLine("<tr><td style=\"border: 1px solid black;width: 20%;vertical-align: top;\">Stone:</td>");
            builder.AppendLine("<td style=\"border: 1px solid black; vertical-align: top;\">" + var_stone + "</td></tr>");
            builder.AppendLine("<tr><td style=\"border: 1px solid black;vertical-align: top;\">Edge:</td>");
            builder.AppendLine("<td style=\"border: 1px solid black;vertical-align: top;\">" + var_edge + "</td></tr>");
            builder.AppendLine("<tr><td style=\"border: 1px solid black;vertical-align: top;\">Sink:</td>");
            builder.AppendLine("<td style=\"border: 1px solid black;vertical-align: top;\">" + var_sink + "</td></tr></table>");
            builder.AppendLine("<p>Please reply to this email promptly and confirm that the above items are correct. We do not cut the slabs until we receive your confirmation email.</p>");
            builder.AppendLine("<p>Thank you,</p>");
            builder.AppendLine("<p>-<strong> Dave</strong><br><em>817-231-5153<br>817-300-3298</em><br>");
            builder.AppendLine("<a href=\"mailto:info@granitesouthlake.com\" style=\"color:black;text-decoration:none;\">info@granitesouthlake.com</a></p></div></body></html>");


            //message.Body = builder.ToString();

            AlternateView altView = AlternateView.CreateAlternateViewFromString(builder.ToString(), null, System.Net.Mime.MediaTypeNames.Text.Html);
            message.AlternateViews.Add(altView);

            try
            {
                mailClient.Send(message);
            }
            catch (Exception ex)
            {
                string myScript = "\n<script type=\"text/javascript\" language=\"Javascript\" id=\"EventScriptBlock\">\n";
                myScript += "alert('Failed to send Install Email Verification. Please try again later.'); ";
                myScript += "\n\n </script>";
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "myKey", myScript, false);
            }

        }

        private void SendAngiesListReviewRequest()
        {
            MailMessage message = new MailMessage();
            message.From = new MailAddress("webform@granitesouthlake.com");

            message.IsBodyHtml = true;

            // Proper Authentication Details need to be passed when sending email from gmail
            System.Net.NetworkCredential mailAuthentication = new
                System.Net.NetworkCredential("webform@granitesouthlake.com", "2much4me");

            // Smtp Mail server of Gmail is "smpt.gmail.com" and it uses port no. 587
            // For different server like yahoo this details changes and you can
            // Get it from respective server.
            System.Net.Mail.SmtpClient mailClient = new System.Net.Mail.SmtpClient("smtp.granitesouthlake.com", 587);

            // Enable SSL
            //mailClient.EnableSsl = true;
            mailClient.UseDefaultCredentials = false;
            mailClient.Credentials = mailAuthentication;

            string strToName = String.Empty;
            string strToEmail = String.Empty;
            string query2 = "Select CustomerFirstName, Email from tblOnlineQuotes where OnlineQuoteID = " + Request.QueryString["OnlineQuoteID"];
            string connect2 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\DFWwebsiteDB.accdb;Persist Security Info=True";
            OleDbConnection conn2 = new OleDbConnection(connect2);
            OleDbCommand cmd2 = new OleDbCommand(query2, conn2);
            conn2.Open();
            OleDbDataReader CustomerDataReader = cmd2.ExecuteReader();
            while (CustomerDataReader.Read())
            {
                strToName += CustomerDataReader.GetString(0);
                strToEmail += CustomerDataReader.GetString(1);
            }
            CustomerDataReader.Close();
            conn2.Close();

            //add accounts to notify
            message.To.Add(new MailAddress(strToEmail));
            message.ReplyToList.Add(new MailAddress("dhitt0327@yahoo.com"));

            message.Subject = "[DFW Wholesale Granite] - Angie's List Review Request";
            System.Text.StringBuilder builder = new System.Text.StringBuilder();
            builder.AppendLine("<html><body><div style=\"padding:15px;background-color: #F8F8F8; font-family: Georgia, \"Times New Roman\", Times, serif; font-size: large;\">");
            builder.AppendLine("<img src=\"cid:YourPictureId\" /><p>Thank you " + strToName + " for choosing <strong>");
            builder.AppendLine("<a href=\"http://www.granitesouthlake.com\" target=\"_blank\" style=\"color:black;text-decoration:none;\">");
            builder.AppendLine("DFW Wholesale Granite</a></strong> for your project. We appreciate your business. ");
            builder.AppendLine("Please tell us how we did by clicking the link below to evaluate our performance.</p>	");
            builder.AppendLine("<div style=\"border:2px solid #a1a1a1;padding:10px 40px; background:#dddddd;border-radius:25px;font-size:xx-large\">");
            builder.AppendLine("<a href=\"http://www.angieslist.com/AngiesList/Review/7863610\" target=\"_blank\" style=\"color:black;text-decoration:none;\">");
            builder.AppendLine("AngiesList.com / Review / 7863610</a></div>");
            builder.AppendLine("<p>We use Angie's List to assess whether we're doing a good job keeping valued customers like you, happy. ");
            builder.AppendLine("Again, please visit <a href=\"http://www.angieslist.com/AngiesList/Review/7863610\" target=\"_blank\">AngiesList.com</a> ");
            builder.AppendLine("in order to grade our quality of work and customer service.</p>	");
            builder.AppendLine("<p>-<strong> Dave</strong><br><em>817-231-5153<br>817-300-3298</em><br>");
            builder.AppendLine("<a href=\"mailto:info@granitesouthlake.com\" style=\"color:black;text-decoration:none;\">info@granitesouthlake.com</a></p></div></body></html>");


            //message.Body = builder.ToString();

            AlternateView altView = AlternateView.CreateAlternateViewFromString(builder.ToString(), null, System.Net.Mime.MediaTypeNames.Text.Html);

            LinkedResource yourPictureRes = new LinkedResource(Server.MapPath("/images/allogo.gif"), System.Net.Mime.MediaTypeNames.Image.Gif);
            yourPictureRes.ContentId = "YourPictureId";
            altView.LinkedResources.Add(yourPictureRes);

            message.AlternateViews.Add(altView);

            try
            {
                mailClient.Send(message);
                string myScript = "\n<script type=\"text/javascript\" language=\"Javascript\" id=\"EventScriptBlock\">\n";
                myScript += "alert('Angies List Review Request was successfuly sent.'); ";
                myScript += "\n\n </script>";
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "myKey", myScript, false);
            }
            catch (Exception ex)
            {
                //Response.Write("Failed to send Angie's List Customer Review Request email. Please try again later.");
                string myScript = "\n<script type=\"text/javascript\" language=\"Javascript\" id=\"EventScriptBlock\">\n";
                myScript += "alert('An error had occured. Angies List Review Request Sending failed.'); ";
                myScript += "\n\n </script>";
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "myKey", myScript, false);
            }

        }

    }
}