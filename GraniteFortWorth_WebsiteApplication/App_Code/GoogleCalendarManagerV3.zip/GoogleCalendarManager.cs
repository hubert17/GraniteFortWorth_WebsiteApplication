﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;
using System.Threading;
using Google.Apis.Calendar.v3;
using Google.Apis.Calendar.v3.Data;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Auth.OAuth2.Flows;
using Google.Apis.Auth.OAuth2.Web;
using Google.Apis.Services;
using Google.Apis.Util.Store;



public class GoogleCalendarManager
{
        private static string calID = System.Configuration.ConfigurationManager.AppSettings["GoogleInstallCalendarID"].ToString();
        private static string UserId = System.Web.HttpContext.Current.User.Identity.Name;
        private static string gFolder = System.Web.HttpContext.Current.Server.MapPath("/App_Data/MyGoogleStorage");

        public static CalendarService getCalendarService()
        {
            CalendarService service = null;

            IAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow(
                new GoogleAuthorizationCodeFlow.Initializer
                {
                    ClientSecrets = GetClientConfiguration().Secrets,
                    DataStore = new FileDataStore(gFolder),
                    Scopes = new[] { CalendarService.Scope.Calendar }
                });

            var uri = System.Web.HttpContext.Current.Request.Url.ToString();
            var code = System.Web.HttpContext.Current.Request["code"];
            if (code != null)
            {
                var token = flow.ExchangeCodeForTokenAsync(UserId, code,
                    uri.Substring(0, uri.IndexOf("?")), CancellationToken.None).Result;

                // Extract the right state.
                var oauthState = AuthWebUtility.ExtracRedirectFromState(
                    flow.DataStore, UserId, System.Web.HttpContext.Current.Request["state"]).Result;
                System.Web.HttpContext.Current.Response.Redirect(oauthState);
            }
            else
            {
                var result = new AuthorizationCodeWebApp(flow, uri, uri).AuthorizeAsync(UserId,
                    CancellationToken.None).Result;
                if (result.RedirectUri != null)
                {
                    // Redirect the user to the authorization server.
                    System.Web.HttpContext.Current.Response.Redirect(result.RedirectUri);
                }
                else
                {
                    // The data store contains the user credential, so the user has been already authenticated.
                    service = new CalendarService(new BaseClientService.Initializer
                    {
                        ApplicationName = "DFW Install Calendar ASP.NET",
                        HttpClientInitializer = result.Credential
                    });
                }
            }

            return service;
        }

        public static GoogleClientSecrets GetClientConfiguration()
        {
            using (var stream = new FileStream(gFolder + @"\client_secrets.json", FileMode.Open, FileAccess.Read))
            {
                return GoogleClientSecrets.Load(stream);
            }
        }

        public static bool AddUpdateDeleteEvent(List<GoogleCalendarAppointmentModel> GoogleCalendarAppointmentModelList, double TimeOffset)
        {
            bool result = false;
            
            //Get the calendar service for a user to add/update/delete events
            CalendarService calService = getCalendarService();

            if (GoogleCalendarAppointmentModelList != null && GoogleCalendarAppointmentModelList.Count > 0)
            {
                foreach (GoogleCalendarAppointmentModel GoogleCalendarAppointmentModelObj in GoogleCalendarAppointmentModelList)
                {
                    EventsResource er = new EventsResource(calService);
                    string ExpKey = "EventID";
                    string ExpVal = GoogleCalendarAppointmentModelObj.EventID;

                    //to restrict the appointment for specific staff only
                    //Delete this appointment from google calendar
                    if (GoogleCalendarAppointmentModelObj.DeleteAppointment == true)
                    {
                        var queryEvent = er.List(calID);

                        queryEvent.SharedExtendedProperty = ExpKey + "=" + ExpVal; //"EventID=9999"
                        var EventsList = queryEvent.Execute();

                        string FoundEventID = String.Empty;
                        foreach (Event evItem in EventsList.Items)
                        {
                            FoundEventID = evItem.Id;
                            er.Delete(calID, FoundEventID).Execute();
                            result =  true;
                        }

                    }
                    //Add if not found OR update if appointment already present on google calendar
                    else
                    {
                        var queryEvent = er.List(calID);
                        queryEvent.SharedExtendedProperty = ExpKey + "=" + ExpVal; //"EventKey=9999"
                        var EventsList = queryEvent.Execute();

                        Event eventEntry = new Event();
                        EventDateTime StartDate = new EventDateTime();
                        StartDate.Date = GoogleCalendarAppointmentModelObj.EventStartTime.ToString("yyyy-MM-dd"); //"2014-11-17";
                        EventDateTime EndDate = new EventDateTime();
                        EndDate.Date = StartDate.Date;

                        eventEntry.Summary = GoogleCalendarAppointmentModelObj.EventTitle;
                        eventEntry.Start = StartDate;
                        eventEntry.End = EndDate;
                        eventEntry.Location = GoogleCalendarAppointmentModelObj.EventLocation;
                        eventEntry.Description = GoogleCalendarAppointmentModelObj.EventDetails;

                        string FoundEventID = String.Empty;
                        foreach (var evItem in EventsList.Items)
                        {
                            FoundEventID = evItem.Id;
                        }

                        if (String.IsNullOrEmpty(FoundEventID))
                        {
                            //Append Extended Property and create the event
                            Event.ExtendedPropertiesData exp = new Event.ExtendedPropertiesData();
                            exp.Shared = new Dictionary<string, string>();
                            exp.Shared.Add(ExpKey, ExpVal);
                            eventEntry.ExtendedProperties = exp;
                            er.Insert(eventEntry, calID).Execute();
                            result = true;
                        }
                        else
                        {
                            //Update the event
                            er.Update(eventEntry, calID, FoundEventID).Execute();
                            result = true;
                        }


                        /*
                        Google.GData.Calendar.EventEntry Entry = new Google.GData.Calendar.EventEntry();
                        // Set the title and content of the entry.
                        Entry.Title.Text = GoogleCalendarAppointmentModelObj.EventTitle;

                        System.Text.StringBuilder EventDetails = new System.Text.StringBuilder();
                        EventDetails.Append(GoogleCalendarAppointmentModelObj.EventDetails);                        
                        Entry.Content.Content = EventDetails.ToString();

                        When EventTime = new When();
                        EventTime.AllDay = true;                        
                        EventTime.StartTime = GoogleCalendarAppointmentModelObj.EventStartTime.AddDays(1);
                        EventTime.EndTime = GoogleCalendarAppointmentModelObj.EventEndTime.AddDays(1);

                        Entry.Times.Add(EventTime);
                        

                        // Set a location for the event.
                        Where eventLocation = new Where();
                        if (string.IsNullOrEmpty(GoogleCalendarAppointmentModelObj.EventLocation) == false)
                        {
                            eventLocation.ValueString = GoogleCalendarAppointmentModelObj.EventLocation;
                            Entry.Locations.Add(eventLocation);
                        }
                        //Add appointment ID to update/ delete the appointment afterwards
                        ExtendedProperty oExtendedProperty = new ExtendedProperty();
                        oExtendedProperty.Name = "EventID";
                        oExtendedProperty.Value = GoogleCalendarAppointmentModelObj.EventID;
                        Entry.ExtensionElements.Add(oExtendedProperty);

                        //search the calendar so to update or add appointment in it
                        string ThisFeedUri = "http://www.google.com/calendar/feeds/" + CalendarID + "/private/full";
                        Uri postUri = new Uri(ThisFeedUri);
                        EventQuery Query = new EventQuery(ThisFeedUri);
                        Query.ExtraParameters = "extq=[EventID:" + GoogleCalendarAppointmentModelObj.EventID + "]";
                        Query.Uri = postUri;
                        Entry.ExtensionElements.Add(oExtendedProperty);
                        EventFeed calFeed = CalService.Query(Query);

                        //if search contains result then update
                        if (calFeed != null && calFeed.Entries.Count > 0)
                        {
                            foreach (EventEntry SearchedEntry in calFeed.Entries)
                            {
                                SearchedEntry.Content = Entry.Content;
                                SearchedEntry.Title = Entry.Title;
                                SearchedEntry.Times.RemoveAt(0);
                                SearchedEntry.Times.Add(EventTime);
                                SearchedEntry.Locations.RemoveAt(0);
                                SearchedEntry.Locations.Add(eventLocation);

                                CalService.Update(SearchedEntry);
                                result = true;
                                break;
                            }
                        }
                        //otherwise add the entry
                        else
                        {
                            InsertedEntry = CalService.Insert(postUri, Entry);
                            result = true;
                        }
                        */
                    }
                }
            }

            return result ;
        }


}

