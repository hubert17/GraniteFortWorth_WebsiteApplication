﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;

using System.Web.Script.Serialization;
using Google.GData.Client;
using Google.GData.Calendar;
using Google.GData.Extensions;
using System.Net;
using System.Text;
using System.IO;
using System.Xml;

namespace GraniteFortWorth_WebsiteApplication.admin
{
    public partial class GoogleCalendarRegistration : System.Web.UI.Page
    {

        private static string ReturnUrl = @System.Configuration.ConfigurationManager.AppSettings["GoogleReturnPageAddress"].ToString();


        private static string OwnCalendarFeed = @"http://www.google.com/calendar/feeds/default/owncalendars/full";
        private static string AllCalendarFeed = @"http://www.google.com/calendar/feeds/default/allcalendars/full";
        private static string PrivateFeed = @"http://www.google.com/calendar/feeds/default/private/full";
        private static string ClientID = System.Configuration.ConfigurationManager.AppSettings["GoogleCalendarApplicationClientID"].ToString();
        private static string ClientSecret = System.Configuration.ConfigurationManager.AppSettings["GoogleCalendarApplicationClientSecret"].ToString();
        private string AllCalendarFeedURL = @"https://www.google.com/calendar/feeds/default/allcalendars/full";

        XmlDocument XmlDoc = new XmlDocument();
        static string UserID = "UserID";
        static string AccessToken = "AccessToken";
        static string RefreshToken = "RefreshToken";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack == false)
            {
                if (string.IsNullOrEmpty(Request.QueryString["code"]) == false)
                {
                    GoogleTokenModel TokenData = new GoogleTokenModel();
                    string Result = "";
                    try
                    {
                        TokenData = ExchangeCodeWithAccessAndRefreshToken();
                    }
                    catch
                    {
                        Result = "?Error=Internet connectivity problem. Please try later";
                        btnBack.Visible = true;
                    }

                    //If no proper response is given
                    if (string.IsNullOrEmpty(TokenData.Access_Token) == true)
                    {
                        Result = "?Error=Some problem with google registration. Please try later or use a different gmail account to register";
                        btnBack.Visible = true;
                    }

                    //If the gmail account is already registered
                    else if (string.IsNullOrEmpty(TokenData.Access_Token) == false && string.IsNullOrEmpty(TokenData.Refresh_Token) == true)
                    {
                        Result = "?Error=This gmail account is already registered with this application. Click the REVOKE button to renew your calendar access token.";
                        btnRevoke.Visible = true;
                        //RevokeGoogleRights();
                    }
                    //Check if the some error is thrown
                    if (string.IsNullOrEmpty(Result) == false)
                    {
                        LblMessage.Text = Result;
                        return;

                    }

                    //If proper token data is acquired
                    else if (string.IsNullOrEmpty(TokenData.Access_Token) == false && string.IsNullOrEmpty(TokenData.Refresh_Token) == false)
                    {
                        LblMessage.Text = "Registration Complete. You can view that you gmail account is linked with your calendar application here <a href='https://accounts.google.com/b/0/IssuedAuthSubTokens?hl=en' target='blank'>Authorized Access to your Google Account</a> ";

                        XmlDocument XmlDoc = new XmlDocument();
                        XmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\XMLfile.xml");
                        XmlDoc.DocumentElement.SelectSingleNode("//User[@UserID='1']").Attributes["AccessToken"].Value = TokenData.Access_Token;
                        XmlDoc.DocumentElement.SelectSingleNode("//User[@UserID='1']").Attributes["RefreshToken"].Value = TokenData.Refresh_Token;
                        XmlDoc.Save(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\XMLfile.xml");

                        if ((!string.IsNullOrEmpty(Session["strActiveOnlineQuoteID"].ToString())))
                        {
                            try
                            {
                                CreateUpdateGoogleInstallCalendar(Session["strActiveOnlineQuoteID"].ToString());
                            }
                            catch (Exception ex)
                            {
                                LblMessage.Text += " <br/>Failed to update Google Install Calendar. Please go back and try again.";
                            }
                        }
                        HyperLink1.NavigateUrl = "~/admin/EditJob.aspx?OnlineQuoteID=" + Session["strActiveOnlineQuoteID"].ToString();
                        HyperLink1.Visible = true;
                    }
                }
                else
                {
                    //if access denied 
                    if (Request.QueryString["error"] != null)
                    {
                        LblMessage.Text = "Access is Denied. Please login to your google account to update Google Install Calendar.";
                        btnBack.Visible = true;
                    }
                    else
                    {

                    }
                }
            }
        }

        public static string GenerateGoogleOAuthURL()
        {
            string Url = "https://accounts.google.com/o/oauth2/auth?scope={0}&redirect_uri={1}&response_type={2}&client_id={3}&state={4}&access_type={5}&approval_prompt={6}";
            //string scope = UrlEncodeForGoogle("http://www.google.com/calendar/feeds/default/private/full").Replace("%20", "+");
            string scope = UrlEncodeForGoogle(PrivateFeed).Replace("%20", "+");
            string redirect_uri_encode = UrlEncodeForGoogle(ReturnUrl);
            string response_type = "code";
            string state = "";
            string access_type = "offline";
            string approval_prompt = "auto";
            return string.Format(Url, scope, redirect_uri_encode, response_type, ClientID, state, access_type, approval_prompt);
        }
 
        private static string UrlEncodeForGoogle(string url)
        {

            string UnReservedChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_.~";
            var result = new StringBuilder();

            foreach (char symbol in url)
            {
                if (UnReservedChars.IndexOf(symbol) != -1)
                {
                    result.Append(symbol);
                }
                else
                {
                    result.Append('%' + String.Format("{0:X2}", (int)symbol));
                }
            }
            return result.ToString();
        }

        private GoogleTokenModel ExchangeCodeWithAccessAndRefreshToken()
        {
            string Url = "https://accounts.google.com/o/oauth2/token";
            string grant_type = "authorization_code";
            string redirect_uri_encode = UrlEncodeForGoogle(ReturnUrl);
            string data = "code={0}&client_id={1}&client_secret={2}&redirect_uri={3}&grant_type={4}";
            string Code = Request.QueryString["Code"];

            HttpWebRequest request = HttpWebRequest.Create(Url) as HttpWebRequest;
            string result = null;
            request.Method = "POST";
            request.KeepAlive = true;
            request.ContentType = "application/x-www-form-urlencoded";
            string param = string.Format(data, Code, ClientID, ClientSecret, redirect_uri_encode, grant_type);
            var bs = Encoding.UTF8.GetBytes(param);
            using (Stream reqStream = request.GetRequestStream())
            {
                reqStream.Write(bs, 0, bs.Length);
            }

            using (WebResponse response = request.GetResponse())
            {
                var sr = new StreamReader(response.GetResponseStream());
                result = sr.ReadToEnd();
                sr.Close();
            }

            var jsonSerializer = new JavaScriptSerializer();
            var tokenData = jsonSerializer.Deserialize<GoogleTokenModel>(result);

            return tokenData;

        }

        private bool GetNewAccessToken(GoogleTokenModel GoogleTokenModelObj)
        {
            try
            {
                string Url = "https://accounts.google.com/o/oauth2/token";
                string grant_type = "refresh_token";
                string redirect_uri_encode = UrlEncodeForGoogle(ReturnUrl);
                string data = "client_id={0}&client_secret={1}&refresh_token={2}&grant_type={3}";

                HttpWebRequest request = HttpWebRequest.Create(Url) as HttpWebRequest;
                string result = null;
                request.Method = "POST";
                request.KeepAlive = true;
                request.ContentType = "application/x-www-form-urlencoded";
                string param = string.Format(data, ClientID, ClientSecret, GoogleTokenModelObj.Refresh_Token, grant_type);
                var bs = Encoding.UTF8.GetBytes(param);
                using (Stream reqStream = request.GetRequestStream())
                {
                    reqStream.Write(bs, 0, bs.Length);
                }

                using (WebResponse response = request.GetResponse())
                {
                    var sr = new StreamReader(response.GetResponseStream());
                    result = sr.ReadToEnd();
                    sr.Close();
                }

                var jsonSerializer = new JavaScriptSerializer();
                var TokenData = jsonSerializer.Deserialize<GoogleTokenModel>(result);

                GoogleTokenModelObj.Access_Token = TokenData.Access_Token;
                if (TokenData.Refresh_Token != null)
                    GoogleTokenModelObj.Refresh_Token = TokenData.Refresh_Token;
                //GoogleTokenModelObj.LastAccessDateTime = DateTime.Now;

                //Update the refresh and access token in DB for next login usage
                //GoogleCalendarManager.UpdateRefreshTokenInGoogleAppointmentOAuth(GoogleTokenModelObj);
                XmlDocument XmlDoc = new XmlDocument();
                XmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\XMLfile.xml");
                XmlDoc.DocumentElement.SelectSingleNode("//User[@UserID='1']").Attributes["AccessToken"].Value = TokenData.Access_Token;
                XmlDoc.DocumentElement.SelectSingleNode("//User[@UserID='1']").Attributes["RefreshToken"].Value = TokenData.Refresh_Token;
                XmlDoc.Save(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\XMLfile.xml");

                return true;

            }
            catch
            {
                return false;
            }
        }


        protected void CreateUpdateGoogleInstallCalendar(string strOnlineQuoteID)
        {
            List<GoogleCalendarAppointmentModel> GoogleCalendarAppointmentModelList = new List<GoogleCalendarAppointmentModel>();
            List<GoogleTokenModel> GoogleTokenModelList = new List<GoogleTokenModel>();

            GoogleCalendarAppointmentModel GoogleCalendarAppointmentModelObj = new GoogleCalendarAppointmentModel();
            GoogleTokenModel GoogleTokenModelObj = new GoogleTokenModel();

            #region populate GoogleAppointment values

            //Retrieve Granite/SF info
            string query2 = "SELECT SlabColorName AS SLABNAME, str(SF) + 'sf ' AS SFVAL FROM SummaryStoneQry WHERE OnlineQuoteID = " + strOnlineQuoteID;
            string connect2 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\DFWwebsiteDB.accdb;Persist Security Info=True";
            OleDbConnection conn2 = new OleDbConnection(connect2);
            OleDbCommand cmd2 = new OleDbCommand(query2, conn2);
            conn2.Open();
            OleDbDataReader JobInfoDataReader2 = cmd2.ExecuteReader();

            int c = 1;
            while (JobInfoDataReader2.Read())
            {
                if (c < 2)
                    GoogleCalendarAppointmentModelObj.EventDetails += "STONE:" + JobInfoDataReader2.GetValue(1).ToString() + JobInfoDataReader2.GetValue(0).ToString();
                else
                    GoogleCalendarAppointmentModelObj.EventDetails += "," + JobInfoDataReader2.GetValue(1).ToString() + JobInfoDataReader2.GetValue(0).ToString();
                c++;
            }
            JobInfoDataReader2.Close();
            conn2.Close();

            GoogleCalendarAppointmentModelObj.EventDetails += " | EDGE: " + Session["strActiveEdge"].ToString();

            //Retrieve Sink info
            string query5 = "SELECT SinkName, Quantity FROM SummarySinksQry WHERE OnlineQuoteID = " + strOnlineQuoteID;
            string connect5 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\DFWwebsiteDB.accdb;Persist Security Info=True";
            OleDbConnection conn5 = new OleDbConnection(connect5);
            OleDbCommand cmd5 = new OleDbCommand(query5, conn5);
            conn5.Open();
            OleDbDataReader JobInfoDataReader5 = cmd5.ExecuteReader();

            int c5 = 1;
            while (JobInfoDataReader5.Read())
            {
                if (c5 < 2)
                    GoogleCalendarAppointmentModelObj.EventDetails += " | SINK: " + JobInfoDataReader5.GetValue(1).ToString() + " " + JobInfoDataReader5.GetValue(0).ToString();
                else
                    GoogleCalendarAppointmentModelObj.EventDetails += ", " + JobInfoDataReader5.GetValue(1).ToString() + " " + JobInfoDataReader5.GetValue(0).ToString();
                c5++;
            }
            JobInfoDataReader5.Close();
            conn5.Close();


            //Retrieve Customer Install Info
            string query1 = "SELECT CustomerFirstName + ' ' + CustomerLastName AS CustomerName, Address + ', ' + City + ', ' + State  AS InstallAddress, "
                + " InstallDate, InstallTime, Notes, ZipCode  FROM tblOnlineQuotes WHERE OnlineQuoteID = " + strOnlineQuoteID;
            string connect1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\DFWwebsiteDB.accdb;Persist Security Info=True";
            OleDbConnection conn1 = new OleDbConnection(connect1);
            OleDbCommand cmd1 = new OleDbCommand(query1, conn1);
            conn1.Open();
            OleDbDataReader JobInfoDataReader = cmd1.ExecuteReader();

            while (JobInfoDataReader.Read())
            {
                GoogleCalendarAppointmentModelObj.EventID = strOnlineQuoteID;
                GoogleCalendarAppointmentModelObj.EventTitle = JobInfoDataReader.GetString(0) + " Install";
                GoogleCalendarAppointmentModelObj.EventStartTime = DateTime.Parse(JobInfoDataReader.GetDateTime(2).ToShortDateString()).AddHours(-2);
                GoogleCalendarAppointmentModelObj.EventEndTime = GoogleCalendarAppointmentModelObj.EventStartTime.AddHours(2);
                //Giving the proper location so you can view on the map in google calendar
                GoogleCalendarAppointmentModelObj.EventLocation = JobInfoDataReader.GetValue(1).ToString() + " " + JobInfoDataReader.GetValue(5).ToString();
                GoogleCalendarAppointmentModelObj.EventDetails += " | INSTALL TIME: " + JobInfoDataReader.GetValue(3).ToString() + " | NOTES: " + JobInfoDataReader.GetValue(4).ToString();
            }
            JobInfoDataReader.Close();
            conn1.Close();

            GoogleCalendarAppointmentModelList.Add(GoogleCalendarAppointmentModelObj);


            #endregion

            #region populate GoogleToken values

            if (XmlDoc.HasChildNodes == false)
            {
                XmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\XMLfile.xml");
            }

            GoogleTokenModelObj.Access_Token = XmlDoc.DocumentElement.SelectSingleNode("//User[@UserID='1']").Attributes[AccessToken].Value;
            GoogleTokenModelObj.Refresh_Token = XmlDoc.DocumentElement.SelectSingleNode("//User[@UserID='1']").Attributes[RefreshToken].Value;
            GoogleTokenModelList.Add(GoogleTokenModelObj);

            #endregion
            #region Add event to google calendar

            //if (GoogleCalendarManager.AddUpdateDeleteEvent(GoogleTokenModelList, GoogleCalendarAppointmentModelList, 0) == true)
            if (GoogleCalendarManager.AddUpdateDeleteEvent(GoogleCalendarAppointmentModelList, 0) == true)
            {
                //LblMessage.Text = "Event Created / updated successfully. Go to <a href='https://www.google.com/calendar/' target='blank'>Google Calendar</a> to view your event ";
                //BtnDeleteEvent.Enabled = true;
            }
            #endregion

        }

        protected void RevokeGoogleRights()
        {
            if (XmlDoc.HasChildNodes == false)
            {
                XmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\XMLfile.xml");
            }

            string Access_Token = XmlDoc.DocumentElement.SelectSingleNode("//User[@UserID='1']").Attributes[AccessToken].Value;
            string Refresh_Token = XmlDoc.DocumentElement.SelectSingleNode("//User[@UserID='1']").Attributes[RefreshToken].Value;

            //Attempt the revoke from google
            //if successful then do a db / xml delete as well
            if (GoogleCalendarManager.RevokeAccessToken(Access_Token, Refresh_Token) == true)
            {
                XmlDoc.DocumentElement.SelectSingleNode("//User[@UserID='1']").Attributes[AccessToken].Value = "";
                XmlDoc.DocumentElement.SelectSingleNode("//User[@UserID='1']").Attributes[RefreshToken].Value = "";

                XmlDoc.Save(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\XMLfile.xml");

                //LblMessage.Text += " Rights revoked successfully.You can <a href='https://accounts.google.com/b/0/IssuedAuthSubTokens?hl=en' target='blank'>view</a> that you gmail account is not linked with your calendar application anymore";
                Response.Redirect(GoogleCalendarManager.GenerateGoogleOAuthURL());
            }
        }

        protected void btnRevoke_Click(object sender, EventArgs e)
        {
            RevokeGoogleRights();
        }

    }
}