﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Xml;

using Google.AccessControl;
using Google.GData;
using Google.GData.Calendar;
using Google.GData.AccessControl;
using Google.GData.Client;

namespace GraniteFortWorth_WebsiteApplication.admin
{
    public partial class Jobs_info : System.Web.UI.Page
    {
        XmlDocument XmlDoc = new XmlDocument();

        static string UserID = "UserID";
        static string AccessToken = "AccessToken";
        static string RefreshToken = "RefreshToken";

        private string strStatusID = String.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {

            if (FormView2.CurrentMode == FormViewMode.Edit)
            {
                TextBox txtUserJob = (TextBox)FormView2.FindControl("UserJobNoTextBox");
                if (String.IsNullOrEmpty(txtUserJob.Text))
                {
                    txtUserJob.Text = ((Label)(FormView2.FindControl("OnlineQuoteIDLabel1"))).Text;
                }
            }
            else
            {
                if (strStatusID == "8")
                {
                    string myScript = "\n<script type=\"text/javascript\" language=\"Javascript\" id=\"EventScriptBlock\">\n";
                    myScript += "alert('Job status is now Reference. It is highly recommended to ask this customer to write us a review in Angies List.'); ";
                    myScript += "\n\n </script>";
                    Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "myKey", myScript, false);
                }
            }

        }


        protected void EditButton_Click(object sender, EventArgs e)
        {
            /*
            Label txtUserJob = (Label)FormView2.FindControl("UserJobNoLabel");
                 if (String.IsNullOrEmpty(txtUserJob.Text))
                 {
                     string query = "UPDATE tblOnlineQuotes SET UserJobNo = " + (Convert.ToInt32(((Label)FormView2.FindControl("OnlineQuoteIDLabel")).Text) + 331) + " WHERE OnlineQuoteID = " + Request.QueryString["OnlineQuoteID"];
                     string connect = SqlDataSource2.ConnectionString;
                     OleDbConnection conn = new OleDbConnection(connect);
                     OleDbCommand cmd = new OleDbCommand(query, conn);
                     conn.Open();
                     cmd.ExecuteNonQuery();
                     conn.Close();
                 }
             * */
        }

        protected void UpdateButton_Click(object sender, EventArgs e)
        {
            /*
            TextBox txtUserJob = (TextBox)FormView2.FindControl("UserJobNoTextBox");
            if (String.IsNullOrEmpty(txtUserJob.Text))
            {
                string query = "UPDATE tblOnlineQuotes SET UserJobNo = " + (Convert.ToInt32(((Label)FormView2.FindControl("OnlineQuoteIDLabel1")).Text) + 331) + " WHERE OnlineQuoteID = " + Request.QueryString["OnlineQuoteID"];
                string connect = SqlDataSource2.ConnectionString;
                OleDbConnection conn = new OleDbConnection(connect);
                OleDbCommand cmd = new OleDbCommand(query, conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
             */
        }

        protected string FindEditControl(string ControlID)
        {
            string ControlName = string.Empty;
            if (FormView2.CurrentMode == FormViewMode.Edit)
                ControlName = FormView2.FindControl(ControlID).ClientID;
            else
                ControlName = FormView2.FindControl("TrushControlTextBox").ClientID; 

            return ControlName;
        }

        protected void FormView2_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
        {
            strStatusID = ((DropDownList)FormView2.FindControl("DropDownList5")).SelectedValue;
            string strOnlineQuoteID = Request.QueryString["OnlineQuoteID"];
            
            DateTime dateValue;
            
            if (strStatusID == "8")
            {
                string myScript = "\n<script type=\"text/javascript\" language=\"Javascript\" id=\"EventScriptBlock\">\n";
                myScript += "var r=confirm('You have just change the status of this job into Reference. Would you like to ask this customer to write a review in Angies List?'); ";
                myScript += "if (r==true) self.parent.location='RequestCustomerReview.ashx?OnlineQuoteID=" + strOnlineQuoteID + "'; ";
                myScript += "\n\n </script>";
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "myKey", myScript, false);

            }
            else if (strStatusID == "6" && DateTime.TryParse(((TextBox)FormView2.FindControl("InstallDateTextBox")).Text, out dateValue))
            {
                try
                {
                    CreateUpdateGoogleInstallCalendar(strOnlineQuoteID);                                                      
                }
                catch (Exception ex)
                {
                    Session.Add("strActiveOnlineQuoteID", strOnlineQuoteID);
                    Session.Add("strActiveEdge", ((DropDownList)FormView2.FindControl("EdgeDropDownList1")).SelectedItem.Text);
                    string myScript2 = "self.parent.location='" + GoogleCalendarManager.GenerateGoogleOAuthURL() + "';";
                    this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "myUniqueKey2", myScript2, true);
                }
            }
            else if (strStatusID == "9")
            {
                try
                {
                    DeleteGoogleInstallCalendar(strOnlineQuoteID);
                }
                catch (Exception ex)
                {
                    Session.Add("strActiveOnlineQuoteID", strOnlineQuoteID);
                    Session.Add("strActiveEdge", ((DropDownList)FormView2.FindControl("EdgeDropDownList1")).SelectedItem.Text);
                    string myScript2 = "self.parent.location='" + GoogleCalendarManager.GenerateGoogleOAuthURL() + "';";
                    this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "myUniqueKey2", myScript2, true);
                }
            }

            //((Image)FormView2.FindControl("ImageProgress")).Visible = false;
            /*
            string query = "Select StatusID from tblOnlineQuotes  WHERE OnlineQuoteID = '" +  Request.QueryString["OnlineQuoteID"];
            string connect = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\DFWwebsiteDB.accdb;Persist Security Info=True";
            OleDbConnection conn = new OleDbConnection(connect);
            OleDbCommand cmd = new OleDbCommand(query, conn);
            conn.Open();
            int intResult;
            try
            {
                intResult = Convert.ToInt16(Convert.ToString(cmd.ExecuteScalar()));
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            conn.Close();
             * */
        }

        protected void CreateUpdateGoogleInstallCalendar(string strOnlineQuoteID)
        {          
            List<GoogleCalendarAppointmentModel> GoogleCalendarAppointmentModelList = new List<GoogleCalendarAppointmentModel>();
            List<GoogleTokenModel> GoogleTokenModelList = new List<GoogleTokenModel>();

            GoogleCalendarAppointmentModel GoogleCalendarAppointmentModelObj = new GoogleCalendarAppointmentModel();
            GoogleTokenModel GoogleTokenModelObj = new GoogleTokenModel();

            #region populate GoogleAppointment values

            //Retrieve Granite/SF info
            string query2 = "SELECT SlabColorName AS SLABNAME, str(SF) + 'sf ' AS SFVAL FROM SummaryStoneQry WHERE OnlineQuoteID = " + strOnlineQuoteID;
            string connect2 = SqlDataSource2.ConnectionString;
            OleDbConnection conn2 = new OleDbConnection(connect2);
            OleDbCommand cmd2 = new OleDbCommand(query2, conn2);
            conn2.Open();
            OleDbDataReader JobInfoDataReader2 = cmd2.ExecuteReader();

            int c=1;
            while (JobInfoDataReader2.Read())
            {
                if (c < 2)
                {
                    if(!String.IsNullOrEmpty(JobInfoDataReader2.GetValue(1).ToString()))
                        GoogleCalendarAppointmentModelObj.EventDetails += "STONE:" + JobInfoDataReader2.GetValue(1).ToString() + JobInfoDataReader2.GetValue(0).ToString();
                }
                else
                    GoogleCalendarAppointmentModelObj.EventDetails += "," + JobInfoDataReader2.GetValue(1).ToString() + JobInfoDataReader2.GetValue(0).ToString();
                c++;
            }
            JobInfoDataReader2.Close();
            conn2.Close();

            string strCurrentEdge = ((DropDownList)FormView2.FindControl("EdgeDropDownList1")).SelectedItem.Text;
            GoogleCalendarAppointmentModelObj.EventDetails += !String.IsNullOrEmpty(strCurrentEdge) ? " | EDGE: " + strCurrentEdge : String.Empty;
            ;

            //Retrieve Sink info
            string query5 = "SELECT SinkName, Quantity FROM SummarySinksQry WHERE OnlineQuoteID = " + strOnlineQuoteID;
            string connect5 = SqlDataSource2.ConnectionString;
            OleDbConnection conn5 = new OleDbConnection(connect5);
            OleDbCommand cmd5 = new OleDbCommand(query5, conn5);
            conn5.Open();
            OleDbDataReader JobInfoDataReader5 = cmd5.ExecuteReader();

            int c5 = 1;
            while (JobInfoDataReader5.Read())
            {
                if (c5 < 2)
                {
                    if(!String.IsNullOrEmpty(JobInfoDataReader5.GetValue(1).ToString()))
                        GoogleCalendarAppointmentModelObj.EventDetails += " | SINK: " + JobInfoDataReader5.GetValue(1).ToString() + " " + JobInfoDataReader5.GetValue(0).ToString();
                }
                else
                    GoogleCalendarAppointmentModelObj.EventDetails += ", " + JobInfoDataReader5.GetValue(1).ToString() + " " + JobInfoDataReader5.GetValue(0).ToString();
                c5++;
            }
            JobInfoDataReader5.Close();
            conn5.Close();
           

            //Retrieve Customer Install Info
            string query1 = "SELECT CustomerFirstName + ' ' + CustomerLastName AS CustomerName, Address + ', ' + City + ', ' + State  AS InstallAddress, "
                + " InstallDate, InstallTime, Notes, ZipCode  FROM tblOnlineQuotes WHERE OnlineQuoteID = " + strOnlineQuoteID;
            string connect1 = SqlDataSource2.ConnectionString;
            OleDbConnection conn1 = new OleDbConnection(connect1);
            OleDbCommand cmd1 = new OleDbCommand(query1, conn1);
            conn1.Open();
            OleDbDataReader JobInfoDataReader = cmd1.ExecuteReader();

            while (JobInfoDataReader.Read())
            {
                GoogleCalendarAppointmentModelObj.EventID = strOnlineQuoteID;
                GoogleCalendarAppointmentModelObj.EventTitle = JobInfoDataReader.GetString(0) + " Install";
                GoogleCalendarAppointmentModelObj.EventStartTime = DateTime.Parse(JobInfoDataReader.GetDateTime(2).ToShortDateString()).AddHours(-2);
                GoogleCalendarAppointmentModelObj.EventEndTime = GoogleCalendarAppointmentModelObj.EventStartTime.AddHours(2);
                //Giving the proper location so you can view on the map in google calendar
                GoogleCalendarAppointmentModelObj.EventLocation = JobInfoDataReader.GetValue(1).ToString() + " " + JobInfoDataReader.GetValue(5).ToString();
                GoogleCalendarAppointmentModelObj.EventDetails += !String.IsNullOrEmpty(JobInfoDataReader.GetValue(3).ToString()) ? " | INSTALL TIME: " + JobInfoDataReader.GetValue(3).ToString() : String.Empty;
                GoogleCalendarAppointmentModelObj.EventDetails += !String.IsNullOrEmpty(JobInfoDataReader.GetValue(4).ToString()) ? " | NOTES: " + JobInfoDataReader.GetValue(4).ToString() : String.Empty;
            }
            JobInfoDataReader.Close();
            conn1.Close();
            
            GoogleCalendarAppointmentModelList.Add(GoogleCalendarAppointmentModelObj);


            #endregion

            #region populate GoogleToken values

            if (XmlDoc.HasChildNodes == false)
            {
                XmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\XMLfile.xml");
            }

            GoogleTokenModelObj.Access_Token = XmlDoc.DocumentElement.SelectSingleNode("//User[@UserID='1']").Attributes[AccessToken].Value;
            GoogleTokenModelObj.Refresh_Token = XmlDoc.DocumentElement.SelectSingleNode("//User[@UserID='1']").Attributes[RefreshToken].Value;
            GoogleTokenModelList.Add(GoogleTokenModelObj);

            #endregion

            #region Add event to google calendar

            if (GoogleCalendarManager.AddUpdateDeleteEvent(GoogleTokenModelList, GoogleCalendarAppointmentModelList, 0) == true)
            {
                //LblMessage.Text = "Event Created / updated successfully. Go to <a href='https://www.google.com/calendar/' target='blank'>Google Calendar</a> to view your event ";
                //BtnDeleteEvent.Enabled = true;
            }
            #endregion

        }


        protected void DeleteGoogleInstallCalendar(string strOnlineQuoteID)
        {
            List<GoogleCalendarAppointmentModel> GoogleCalendarAppointmentModelList = new List<GoogleCalendarAppointmentModel>();
            List<GoogleTokenModel> GoogleTokenModelList = new List<GoogleTokenModel>();

            GoogleCalendarAppointmentModel GoogleCalendarAppointmentModelObj = new GoogleCalendarAppointmentModel();
            GoogleTokenModel GoogleTokenModelObj = new GoogleTokenModel();

            #region populate GoogleAppointment values
            GoogleCalendarAppointmentModelObj.EventID = strOnlineQuoteID;
            GoogleCalendarAppointmentModelObj.DeleteAppointment = true;
            GoogleCalendarAppointmentModelList.Add(GoogleCalendarAppointmentModelObj);
            #endregion
            #region populate GoogleToken values

            if (XmlDoc.HasChildNodes == false)
            {
                XmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\XMLfile.xml");
            }

            GoogleTokenModelObj.Access_Token = XmlDoc.DocumentElement.SelectSingleNode("//User[@UserID='1']").Attributes[AccessToken].Value;
            GoogleTokenModelObj.Refresh_Token = XmlDoc.DocumentElement.SelectSingleNode("//User[@UserID='1']").Attributes[RefreshToken].Value;
            GoogleTokenModelList.Add(GoogleTokenModelObj);

            #endregion


                if (GoogleCalendarManager.AddUpdateDeleteEvent(GoogleTokenModelList, GoogleCalendarAppointmentModelList, 0) == true)
                {
                    //XmlDoc.Save(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\XMLfile.xml");
                    //LblMessage.Text = "Event deleted successfully. Go to <a href='https://www.google.com/calendar/' target='blank'>Google Calendar</a> to view your event ";
                    //BtnDeleteEvent.Enabled = false;
                }
        }




    }
}