﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

using Google.AccessControl;
using Google.GData;
using Google.GData.Calendar;
using Google.GData.AccessControl;
using Google.GData.Client;

namespace GraniteFortWorth_WebsiteApplication.admin
{
    public partial class GoogleCalendarInstall : System.Web.UI.Page
    {

        XmlDocument XmlDoc = new XmlDocument();

        static string UserID = "UserID";
        static string UserName = "UserName";
        static string Password = "Password";
        static string AccessToken = "AccessToken";
        static string RefreshToken = "RefreshToken";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                try
                {
                    if (XmlDoc.HasChildNodes == false)
                    {
                        XmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\XMLfile.xml");
                    }
                    //check if the user has logged in
                    if (Session[UserID] != null && string.IsNullOrEmpty(Session[UserID].ToString()) == false)
                    {
                        //if the user is registered
                        if (string.IsNullOrEmpty(XmlDoc.DocumentElement.ChildNodes[0].Attributes[AccessToken].Value.ToString()) == false)
                        {
                            PnlLogin.Visible = false;
                            PnlRegister.Visible = false;
                            PnlEvents.Visible = true;

                            TxtStartTime.Text = DateTime.Now.ToString();
                            TxtEndTime.Text = DateTime.Now.AddHours(2).ToString();

                            //check if event is created or not
                            if (XmlDoc.DocumentElement.SelectSingleNode("//Event").Attributes["EventTitle"].Value == "")
                            {
                                BtnDeleteEvent.Enabled = false;
                            }
                            else
                            {
                                TxtTitle.Text = XmlDoc.DocumentElement.SelectSingleNode("//Event").Attributes["EventTitle"].Value;
                                TxtStartTime.Text = XmlDoc.DocumentElement.SelectSingleNode("//Event").Attributes["EventStartTime"].Value;
                                TxtEndTime.Text = XmlDoc.DocumentElement.SelectSingleNode("//Event").Attributes["EventEndTime"].Value;
                                TxtEventDetails.Text = XmlDoc.DocumentElement.SelectSingleNode("//Event").Attributes["EventDetails"].Value;

                                BtnDeleteEvent.Enabled = true;
                            }
                        }
                        else
                        {
                            PnlLogin.Visible = false;
                            PnlRegister.Visible = true;
                            PnlEvents.Visible = false;
                        }
                    }

                    else
                    {
                        PnlLogin.Visible = true;
                        PnlRegister.Visible = false;
                        PnlEvents.Visible = false;

                        LblMessage.Text = "Please login";
                    }
                }
                catch { }
            }
        }
        protected void BtnLogin_Click(object sender, EventArgs e)
        {
            if (XmlDoc.HasChildNodes == false)
            {
                XmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\XMLfile.xml");
            }

            //check the user credentials
            if (string.IsNullOrEmpty(XmlDoc.DocumentElement.ChildNodes[0].Attributes[UserName].Value.ToString()) == false
             && XmlDoc.DocumentElement.ChildNodes[0].Attributes[UserName].Value.ToLower() == TxtBoxUserName.Text.ToLower()
             && string.IsNullOrEmpty(XmlDoc.DocumentElement.ChildNodes[0].Attributes[Password].Value.ToString()) == false
             && XmlDoc.DocumentElement.ChildNodes[0].Attributes[Password].Value.ToLower() == TxtBoxPwd.Text.ToLower())
            {
                Session[UserID] = XmlDoc.DocumentElement.ChildNodes[0].Attributes[UserID].Value.ToLower();

                //check if the user is registered or not
                //if not then ask the user to register
                if (string.IsNullOrEmpty(XmlDoc.DocumentElement.ChildNodes[0].Attributes[AccessToken].Value.ToString()) == true ||
                string.IsNullOrEmpty(XmlDoc.DocumentElement.ChildNodes[0].Attributes[RefreshToken].Value.ToString()) == true)
                {
                    PnlLogin.Visible = false;
                    PnlRegister.Visible = true;
                    PnlEvents.Visible = false;

                    LblMessage.Text = "Login Successful. Please click the register button to register with google calendar ";
                }

                else
                {
                    PnlLogin.Visible = false;
                    PnlRegister.Visible = false;
                    PnlEvents.Visible = true;

                    //check if event is created or not
                    if (XmlDoc.DocumentElement.SelectSingleNode("//Event").Attributes["EventTitle"].Value == "")
                    {
                        BtnDeleteEvent.Enabled = false;
                        LblMessage.Text = "You can create new event now";
                    }
                    else
                    {
                        TxtTitle.Text = XmlDoc.DocumentElement.SelectSingleNode("//Event").Attributes["EventTitle"].Value;
                        TxtStartTime.Text = XmlDoc.DocumentElement.SelectSingleNode("//Event").Attributes["EventStartTime"].Value;
                        TxtEndTime.Text = XmlDoc.DocumentElement.SelectSingleNode("//Event").Attributes["EventEndTime"].Value;
                        TxtEventDetails.Text = XmlDoc.DocumentElement.SelectSingleNode("//Event").Attributes["EventDetails"].Value;

                        BtnDeleteEvent.Enabled = true;

                        LblMessage.Text = "You can edit / delete this event now";
                    }
                    //PopulateDDLEvent();
                }
            }
            else
            {
                LblMessage.Text = "Login UnSuccessful. Please provide the correct credentials";
            }
        }
        protected void BtnRegisterWithGoogleCalendar_Click(object sender, EventArgs e)
        {
            string GoogleReturnPageAddress = System.Configuration.ConfigurationManager.AppSettings["GoogleReturnPageAddress"];

            Response.Redirect(GoogleCalendarManager.GenerateGoogleOAuthURL());
        }
        protected void BtnRevoke_Click(object sender, EventArgs e)
        {
            if (XmlDoc.HasChildNodes == false)
            {
                XmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\XMLfile.xml");
            }

            string Access_Token = XmlDoc.DocumentElement.SelectSingleNode("//User[@UserID='1']").Attributes[AccessToken].Value;
            string Refresh_Token = XmlDoc.DocumentElement.SelectSingleNode("//User[@UserID='1']").Attributes[RefreshToken].Value;

            //Attempt the revoke from google
            //if successful then do a db / xml delete as well
            if (GoogleCalendarManager.RevokeAccessToken(Access_Token, Refresh_Token) == true)
            {
                XmlDoc.DocumentElement.SelectSingleNode("//User[@UserID='1']").Attributes[AccessToken].Value = "";
                XmlDoc.DocumentElement.SelectSingleNode("//User[@UserID='1']").Attributes[RefreshToken].Value = "";

                XmlDoc.Save(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\XMLfile.xml");

                LblMessage.Text = "Rights revoked successfully.You can <a href='https://accounts.google.com/b/0/IssuedAuthSubTokens?hl=en' target='blank'>view</a> that you gmail account is not linked with your calendar application anymore";

                PnlLogin.Visible = false;
                PnlRegister.Visible = true;
                PnlEvents.Visible = false;

            }
        }
        protected void BtnCreateUpdateEvent_Click(object sender, EventArgs e)
        {
            List<GoogleCalendarAppointmentModel> GoogleCalendarAppointmentModelList = new List<GoogleCalendarAppointmentModel>();
            List<GoogleTokenModel> GoogleTokenModelList = new List<GoogleTokenModel>();

            GoogleCalendarAppointmentModel GoogleCalendarAppointmentModelObj = new GoogleCalendarAppointmentModel();
            GoogleTokenModel GoogleTokenModelObj = new GoogleTokenModel();

            #region populate GoogleAppointment values

            GoogleCalendarAppointmentModelObj.EventID = "1";
            GoogleCalendarAppointmentModelObj.EventTitle =  TxtTitle.Text;
            GoogleCalendarAppointmentModelObj.EventStartTime = Convert.ToDateTime(TxtStartTime.Text).AddHours(-2);
            GoogleCalendarAppointmentModelObj.EventEndTime = GoogleCalendarAppointmentModelObj.EventStartTime.AddHours(2);
            //Giving the proper location so you can view on the map in google calendar
            GoogleCalendarAppointmentModelObj.EventLocation = "Fort Worth, Philippines";
            GoogleCalendarAppointmentModelObj.EventDetails = TxtEventDetails.Text;
            GoogleCalendarAppointmentModelList.Add(GoogleCalendarAppointmentModelObj);
            #endregion

            #region populate GoogleToken values

            if (XmlDoc.HasChildNodes == false)
            {
                XmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\XMLfile.xml");
            }

            GoogleTokenModelObj.Access_Token = XmlDoc.DocumentElement.SelectSingleNode("//User[@UserID='1']").Attributes[AccessToken].Value;
            GoogleTokenModelObj.Refresh_Token = XmlDoc.DocumentElement.SelectSingleNode("//User[@UserID='1']").Attributes[RefreshToken].Value;
            GoogleTokenModelList.Add(GoogleTokenModelObj);

            #endregion
            #region Add event to google calendar

            if (GoogleCalendarManager.AddUpdateDeleteEvent(GoogleTokenModelList, GoogleCalendarAppointmentModelList, 0) == true)
            {
                LblMessage.Text = "Event Created / updated successfully. Go to <a href='https://www.google.com/calendar/' target='blank'>Google Calendar</a> to view your event ";
                BtnDeleteEvent.Enabled = true;
            }
            #endregion

        }
        protected void BtnDeleteEvent_Click(object sender, EventArgs e)
        {
            List<GoogleCalendarAppointmentModel> GoogleCalendarAppointmentModelList = new List<GoogleCalendarAppointmentModel>();
            List<GoogleTokenModel> GoogleTokenModelList = new List<GoogleTokenModel>();

            GoogleCalendarAppointmentModel GoogleCalendarAppointmentModelObj = new GoogleCalendarAppointmentModel();
            GoogleTokenModel GoogleTokenModelObj = new GoogleTokenModel();

            #region populate GoogleAppointment values
            GoogleCalendarAppointmentModelObj.EventID = "1";
            GoogleCalendarAppointmentModelObj.DeleteAppointment = true;
            GoogleCalendarAppointmentModelList.Add(GoogleCalendarAppointmentModelObj);
            #endregion
            #region populate GoogleToken values

            if (XmlDoc.HasChildNodes == false)
            {
                XmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\XMLfile.xml");
            }

            GoogleTokenModelObj.Access_Token = XmlDoc.DocumentElement.SelectSingleNode("//User[@UserID='1']").Attributes[AccessToken].Value;
            GoogleTokenModelObj.Refresh_Token = XmlDoc.DocumentElement.SelectSingleNode("//User[@UserID='1']").Attributes[RefreshToken].Value;
            GoogleTokenModelList.Add(GoogleTokenModelObj);

            #endregion

            if (GoogleCalendarManager.AddUpdateDeleteEvent(GoogleTokenModelList, GoogleCalendarAppointmentModelList, 0) == true)
            {
                if (XmlDoc.HasChildNodes == false)
                {
                    XmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\XMLfile.xml");
                }

                //save data in DB / xml
                XmlDoc.DocumentElement.SelectSingleNode("//Event").Attributes["EventTitle"].Value = "";
                XmlDoc.DocumentElement.SelectSingleNode("//Event").Attributes["EventStartTime"].Value = "";
                XmlDoc.DocumentElement.SelectSingleNode("//Event").Attributes["EventEndTime"].Value = "";
                XmlDoc.DocumentElement.SelectSingleNode("//Event").Attributes["EventLocation"].Value = "";
                XmlDoc.DocumentElement.SelectSingleNode("//Event").Attributes["EventDetails"].Value = "";

                XmlDoc.Save(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\XMLfile.xml");

                LblMessage.Text = "Event deleted successfully. Go to <a href='https://www.google.com/calendar/' target='blank'>Google Calendar</a> to view your event ";

                BtnDeleteEvent.Enabled = false;
            }

        }
        //private void PopulateDDLEvent()
        //{
        //    if (XmlDoc.HasChildNodes == false)
        //    {
        //        XmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + "App_Data\\XMLfile.xml");
        //    }
        //    XmlNodeList AllEventNodes = XmlDoc.DocumentElement.SelectNodes("//Events/Event");
        //    if (AllEventNodes != null && AllEventNodes.Count > 0)
        //    {
        //        foreach (XmlNode XmlNodeObj in AllEventNodes)
        //        {
        //            DDLEvent.Items.Add(new ListItem(XmlNodeObj.Attributes["EventTitle"].Value, XmlNodeObj.Attributes["EventID"].Value));
        //        }
        //    }
        //}
        //protected void DDLEvent_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    if (DDLEvent.SelectedIndex != 0)
        //    {
        //        HdnEventID.Value = DDLEvent.SelectedValue;
        //    }
        //}

    }
}